#!/bin/bash

#make directories
mkdir fastqc_output
mkdir bowtie2_samtools_output
mkdir hmtl_output
mkdir bedtools_output

echo -e "Copying fq files, Tcongo genome and respective bed file........"

#copy fastq files and genome file recursively to current directory
cp -r /localdisk/data/BPSM/AY21/fastq /localdisk/data/BPSM/AY21/Tcongo_genome/ /localdisk/data/BPSM/AY21/TriTrypDB-46_TcongolenseIL3000_2019.bed .; cd fastq

echo -e "Renaming fq files........"

#while read loop for renaming fq files reflecting sample type, time point and induced status. Creating file lists of forward and reverse fq's from sample information file.
IFS=$'\t';
while read ID Sample Replicate Time Treatment End1 End2
do
   echo -e "$End1,$ID.$Sample.$Time.${Treatment}_1.fq.gz" >> forward.files;
done < 100k.fqfiles

while read ID Sample Replicate Time Treatment End1 End2
do
   echo -e "$End2,$ID.$Sample.$Time.${Treatment}_2.fq.gz" >> reverse.files;
done < 100k.fqfiles


#remove header
tail -n +2 forward.files > forward2.files; mv forward2.files forward.files
tail -n +2 reverse.files > reverse2.files; mv reverse2.files reverse.files


#while read loop to rename all fq files with file names from lists.
while IFS=',' read -a line ; do 
   mv "${line[0]}" "${line[1]}"
done < forward.files

while IFS=',' read -a line ; do 
   mv "${line[0]}" "${line[1]}"
done < reverse.files

cd ~

echo -e "First script finished"
